This is a simple meta-class based system for saving objects in the JSON format.

It can make any arbitrary class savable and re-loadable from JSON.

