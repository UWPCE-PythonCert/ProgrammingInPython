#!/usr/bin/env python

"""
A really simple script just to demonstrate packaging
"""

import sys, os
import capital_mod
import main


if __name__ == "__main__":
    main.main()    
